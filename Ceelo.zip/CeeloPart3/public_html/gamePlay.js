var computerPoints = 0;
var humanTokens = 100;

document.getElementById("roll").addEventListener("click", main);

//NEW: getElementById methods have been updated with modified element id's from index.html
function humanTurn(bet) {
    var humanRoll;

    //TO DO: Update the "yourRoll" div to say "Your roll:"
    document.getElementById("yourRoll").innerHTML = "Your roll:";
    do {
        humanRoll = roll();
    } while (!isInstantWin(humanRoll) && !isInstantLoss(humanRoll) && getPoints(humanRoll) === 0);

    //TO DO: call new displayDice function to display human roll
    //document.getElementById("results").innerHTML += humanRoll.join(", ") + "<br>";
    displayDice(humanRoll, false);
    if (isInstantWin(humanRoll)) {
        document.getElementById("humanResults").innerHTML += "<br>Instant win, congratulations!";
        if (is456(humanRoll)) {
            humanTokens += 2 * bet;
            document.getElementById("humanResults").innerHTML += "<br>With 4-5-6 you win double - " + (2 * bet) + " tokens.";
        } else if (isTriple(humanRoll)) {
            if (humanRoll[0] === 1) {
                humanTokens += 5 * bet;
                document.getElementById("humanResults").innerHTML += "<br>With triple 1's you win 5 times your bet - " + (5 * bet) + " tokens.";
            } else {
                humanTokens += 3 * bet;
                document.getElementById("humanResults").innerHTML += "<br>With triple " + humanRoll[0] + "'s you win 3 times your bet - " + (3 * bet) + " tokens.";
            }
        } else {        //won with a double + a 6 
            humanTokens += bet;
            document.getElementById("humanResults").innerHTML += "<br>With a pair of non-6's and a 6 you win " + bet + " tokens.";
        }
    } else if (getPoints(humanRoll) > computerPoints) {
        document.getElementById("humanResults").innerHTML += "<br>You scored " + getPoints(humanRoll) + " points! You win " + bet + " tokens!";
        humanTokens += bet;
    } else if (isInstantLoss(humanRoll)) {
        document.getElementById("humanResults").innerHTML += "<br>Instant loss, computer wins. You lose " + bet + " tokens.";
        humanTokens -= bet;
    } else if (getPoints(humanRoll) < computerPoints) {
        document.getElementById("humanResults").innerHTML += "<br>You scored " + getPoints(humanRoll) + " points. Computer wins. You lose " + bet + " tokens.";
        humanTokens -= bet;
    } else if (getPoints(humanRoll) === computerPoints) {
        document.getElementById("humanResults").innerHTML += "<br>You both scored " + computerPoints + " points. Tie game!";
    } else {
        document.getElementById("humanResults").innerHTML += "<br>Unable to determine winner. Try again.";
    }
}

//main function
function main() {

    var computerRoll;

    var rollOver = false;

    //TO DO: reset set the HTML for a new round
    document.getElementById("humanResults").innerHTML = "<br>";
    document.getElementById("computerResults").innerHTML = "<br>";
    document.getElementById("yourRoll").innerHTML = "<br>";
    var humanBet = Number(document.getElementById("Bet").value);
    if (isNaN(humanBet)) {
        alert("You must place a bet!");
        document.getElementById("Bet").value = '';
    } else if (humanBet <= 0) {
        alert("You must place a bet > 0!");
        document.getElementById("Bet").value = '';
    } else if (humanBet > humanTokens) {
        alert("You cannot bet more than you have!");
        document.getElementById("Bet").value = '';
    } else {

        while (!rollOver) {
            computerRoll = roll();
            if (isInstantWin(computerRoll) ||
                    isInstantLoss(computerRoll) ||
                    getPoints(computerRoll) > 0) {
                rollOver = true;
            }
        }

        //TO DO: call new displayDice function to display computer roll
        displayDice(computerRoll, true);
        
        if (isInstantWin(computerRoll)) {
            humanTokens -= humanBet;
            document.getElementById("computerResults").innerHTML += "Instant computer win! You lose " + humanBet + " tokens.";
            //TO DO: call new function to blank out the human roll
            blankOutHumanRoll();
        } else if (isInstantLoss(computerRoll)) {
            humanTokens += humanBet;
            document.getElementById("computerResults").innerHTML += "Instant computer loss, you win " + humanBet + " tokens!";
            //TO DO: call new function to blank out the human roll
            blankOutHumanRoll();
        } else {
            computerPoints = getPoints(computerRoll);
            document.getElementById("computerResults").innerHTML += "Computer points = " + computerPoints + "<br>";
            humanTurn(humanBet);
        }
    }
    document.getElementById("tokensRemaining").innerHTML = "Tokens remaining: " + humanTokens;
}
