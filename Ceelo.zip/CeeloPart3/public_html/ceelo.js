//////////////////////////////////////////////////////////////////////////////////////////////////////
// START HERE
//////////////////////////////////////////////////////////////////////////////////////////////////////

function roll() {
//    The diceRoll array will hold 3 random integers between 1 and 6,
//    each representing a random dice roll.
    var diceRoll = [];
    
    diceRoll.push(Math.floor(Math.random() * 6 + 1));
    diceRoll.push(Math.floor(Math.random() * 6 + 1));
    diceRoll.push(Math.floor(Math.random() * 6 + 1));    

    return diceRoll;
}

//TO DO: write function to display dice
function displayDice(diceRoll, isComputer) {
    let die;
    if (isComputer){
        die = document.getElementById("die1");
        die.src = "dice-0" + diceRoll[0].toString() + ".png";
        die = document.getElementById("die2");
        die.src = "dice-0" + diceRoll[1].toString() + ".png";
        die = document.getElementById("die3");
        die.src = "dice-0" + diceRoll[2].toString() + ".png";
    }else{
        die = document.getElementById("die4");
        die.src = "dice-0" + diceRoll[0].toString() + ".png";
        die = document.getElementById("die5");
        die.src = "dice-0" + diceRoll[1].toString() + ".png";
        die = document.getElementById("die6");
        die.src = "dice-0" + diceRoll[2].toString() + ".png";
    }
}

//TO DO: write function to blank out dice images
function blankOutHumanRoll() {
    let die;
    die = document.getElementById("die4");
    die.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
    die = document.getElementById("die5");
    die.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
    die = document.getElementById("die6");
    die.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
}

function isInstantWin(diceRoll) {
//    An instant win is one of the following:
//     1) 4-5-6
//     2) All 3 dice the same
//     3) 2 dice the same, and the 3rd die is a 6
//    
//    If the dice meet any of these conditions, return true
//    Otherwise, return false

    if (is456(diceRoll)) {
        return true;
    }
    if (isTriple(diceRoll)) {
        return true;
    }
    if (diceRoll[0] === diceRoll[1] && diceRoll[2] === 6) {
        return true;
    }
    if (diceRoll[0] === diceRoll[2] && diceRoll[1] === 6) {
        return true;
    }
    if (diceRoll[1] === diceRoll[2] && diceRoll[0] === 6) {
        return true;
    }
    return false;
}

function is456(diceRoll) {
    return (diceRoll.includes(4) && diceRoll.includes(5) && diceRoll.includes(6));
}

function isTriple(diceRoll) {
    return (diceRoll[0] === diceRoll[1] && diceRoll[0] === diceRoll[2]);
}

function isInstantLoss(diceRoll) {
//    An instant loss is one of the following:
//    1-2-3
//    2 dice the same, and the 3rd die is a 1
//    If the dice meet any of these conditions, return true
//    Otherwise, return false
    
    if (is123(diceRoll)) {
        return true;
    }
    if (diceRoll[0] === diceRoll[1] && diceRoll[2] === 1) {
        return true;
    }
    if (diceRoll[0] === diceRoll[2] && diceRoll[1] === 1) {
        return true;
    }
    if (diceRoll[1] === diceRoll[2] && diceRoll[0] === 1) {
        return true;
    }
    return false;
}

function is123(diceRoll) {
    return (diceRoll.includes(1) && diceRoll.includes(2) && diceRoll.includes(3));
}

function getPoints(diceRoll) {
//    If 2 dice are the same, 
//    the points = the value of the 3rd die.
//    Otherwise points are 0.
//    Return the points value.
    
    if (diceRoll[0] === diceRoll[1]) {
        return diceRoll[2];
    }
    if (diceRoll[0] === diceRoll[2]) {
        return diceRoll[1];
    }
    if (diceRoll[1] === diceRoll[2]) {
        return diceRoll[0];
    }
    return 0;
}

