var tokens = 100;

function randomSymbol(min,max) {
//Complete this function to return a random number
//Use the random number as the index to your array to choose the symbol for each pull
return Math.floor(Math.random() * (max - min) + min);

}

function PullTheLever() {
    var bet = document.forms["SlotMachine"]["playerBet"].value;
    if (isNaN(bet)) {
        alert("Enter a numeric bet!");
    }
    else {
//Create an array to hold the 6 symbols
let symbols = ["cherries", "orange", 'plum', 'bell', 'melon', 'bar'];
//For each "pull", call the random number function
//Use the number returned as the index to your symbol array
//to retrieve a symbol for each pull
        var pull1, pull2, pull3;
pull1 = symbols[randomSymbol(0,6)];
pull2 = symbols[randomSymbol(0,6)];
pull3 = symbols[randomSymbol(0,6)];

//Build a string to display the "line" of symbols pulled
//See the hint in index.html for writing text to the web page (i.e. the HTML document)
//Remember you can use html tags in your string, like <h2></h2>
        var thisSpin;
        let slot;
thisSpin = [pull1, pull2, pull3];
slot = document.getElementById("slot1");
slot.src = pull1.toString() + ".jpg";
slot = document.getElementById("slot2");
slot.src = pull2.toString() + ".jpg";
slot = document.getElementById("slot3");
slot.src = pull3.toString() + ".jpg";
        //document.getElementById("line").innerHTML = thisSpin.join('-');
        
//Use if statements to figure out how many symbols were matched
//and determine the winnings (if any)
        var winnings = 0;
        //let tokens;
        //var match = 1;
        if (pull1 === pull2) {
            if (pull2 === pull3) {
                winnings = winnings + bet * 3;
                document.getElementById("winngs").innerHTML = "<br>You matched three, you triple your winnings!" + " You won " + winnings;;
            } else {
                winnings = winnings + bet * 2;
                document.getElementById("winnings").innerHTML = "<br>You matched two, you double your winnings!" + " You won " + winnings;
            }
        } else if (pull2 === pull3) {
             winnings = winnings + bet * 2;
            document.getElementById("winnings").innerHTML = "<br>You matched two, you double your winnings!" + " You won " + winnings;
        } else if (pull1 === pull3) {
            winnings = winnings + bet * 2;
            document.getElementById("winnings").innerHTML = "<br>You matched two, you double your winnings!" + " You won " + winnings;
        }else{
          document.getElementById("winnings").innerHTML = "<br>No luck, spin again!"; 
          //tokens = tokens - bet;
         // document.getElementById("").innerHTML = 
       }
    }
    return false;
}

